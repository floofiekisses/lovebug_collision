using System.Collections;
using System.Collections.Generic;
using UnityEngine;
    [RequireComponent(typeof(SpriteRenderer))]
    // require component must be in square brackets
    // automatically adds a sprite renderer to the evil lovebug object
    // this is also an attribute :)
public class Evil_Lovebug_Color_Changer : MonoBehaviour
{

    private SpriteRenderer spriteRenderer; // makes the thing appear in your unity editor
    public float timeToChange = 0.1f;
    // declares variable signlaing how much time needs to pass before the color changes
    private float timeSinceChange = 0f;
    // this is an internal reference variable that checks how much has passed since a color change
    // Start is called before the first frame update
    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        // finds the spriteRenderer component in the game object
    }

    // Update is called once per frame
    private void Update()
    {
        { timeSinceChange += Time.deltaTime;
        // sets a timer where timeSinceChange will increment a specific value
        if(spriteRenderer != null && timeSinceChange >= timeToChange) {
            Color newColor = new Color(Random.value, Random.value, Random.value);
            spriteRenderer.color = newColor;
            timeSinceChange = 0f;
        }
     }
}
}
// if sprite renderer exists, change the color to a new color with random values, and then the sprite renderer will assign that new color to the character
// resets time since change