using System.Collections;
using System.Collections.Generic;
using UnityEngine;
    [RequireComponent(typeof(SpriteRenderer))]
    // require component must be in square brackets
    // automatically adds a sprite renderer to the evil lovebug object
    // this is also an attribute :)
public class NewBehaviourScript : MonoBehaviour
{
    public float moveSpeed; // the movement speed of the character
    public Rigidbody2D rigidbody2D; // the rigid body being used
    private Vector2 moveDirection; // create a new vector that moves in x and y and checks

    // Update is called once per frame
    void Update()
    {
        ProcessInputs(); // tells game to check input every frame
    }

    void FixedUpdate() // good for physics :D
    {
        Move(); // calls the movement direction at a consistent level
    }

    void ProcessInputs() // check inputs
    {
        float moveX = Input.GetAxisRaw("Horizontal");
        float moveY = Input.GetAxisRaw("Vertical");

        moveDirection = new Vector2(moveX, moveY).normalized; // this moves the thing!!
    }
    void Move()
    {
        rigidbody2D.velocity = new Vector2(moveDirection.x * moveSpeed, moveDirection.y * moveSpeed);
    }
    // how to move
    public void onCollisionEnter2D(Collision2D lovebugCollision){
        if(lovebugCollision.gameObject.tag == "SceneTransition"){
            gameOver.Instance.gameOverScene();
        }
    }
}
// detects 2D collisions; if lovebug collides with a game object with the tag "scene transition," it'll call the game over scene instance