using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class gameOver : MonoBehaviour
{
    public static gameOver Instance;
    // makes the game over class a game instance

    private void Awake(){
        if(Instance == null)
        {
            Instance = this;
        } else if (Instance != this) {
            Destroy(gameObject);
        }
    }
    // awake is called before the first frame update; comes before start

    // Update is called once per frame
    public void gameOverScene(){
        SceneManager.LoadScene("game over scene");
    }
    // loads game over scene
}
